# The Haven Garden Hotel Website

A responsive, single-page hotel website for GitHub Pages.

## Included
- Responsive home page and navigation
- About section and gallery
- Room cards with illustrative prices
- Interactive menu tabs (breakfast/snacks, main meals, drinks)
- Booking enquiry form that opens WhatsApp with a pre-filled message
- Contact links for phone, email, and Google Maps search
- Mobile-friendly styling

## Before publishing
1. Confirm that the displayed room prices, menu prices, facilities, and business details are accurate.
2. Replace the illustrative stock photos with real hotel photos if available.
3. The website is a static site. Booking enquiries open WhatsApp; it does not store bookings or automatically confirm reservations.
4. The Google Maps button points to a Sekenani search, not an exact property pin.

## Publish with GitHub Pages on Android
1. Download and extract `haven-garden-hotel-website.zip` on your phone.
2. Open https://github.com and sign in.
3. Tap **+** → **New repository**.
4. Repository name: `haven-garden-hotel`; choose **Public**; create repository.
5. Open the repository → **Add file** → **Upload files**. Upload `index.html` (and `README.md` if you want).
   - Important: `index.html` must be at the repository root, not inside another folder.
6. Commit the uploaded files.
7. Open repository **Settings** → **Pages**.
8. Under **Build and deployment**, choose **Deploy from a branch**.
9. Select branch **main** and folder **/(root)**, then tap **Save**.
10. Wait a few minutes and refresh the Pages screen. GitHub will show your public URL, usually:
    `https://YOUR-USERNAME.github.io/haven-garden-hotel/`
    Replace `YOUR-USERNAME` with your actual GitHub username.
11. Open the URL to test the site on your phone and share it.

## Contact details currently displayed
- Contact person: sucre
- Email: gilishotony@gmail.com
- Phone/WhatsApp: +254783410351
- Location: Sekenani, Kenya
